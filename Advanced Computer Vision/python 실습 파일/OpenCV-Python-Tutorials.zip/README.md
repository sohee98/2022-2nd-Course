# OpenCV-Python-Tutorials
This project was created for study purpose.

Ref:
- [OpenCV-Python Tutorials](http://opencv-python-tutroals.readthedocs.org/en/latest/py_tutorials/py_tutorials.html)
- [OpenCV 2 Computer Vision Application Programming Cookbook](https://www.amazon.ca/OpenCV-Computer-Application-Programming-Cookbook/dp/1849513244)
