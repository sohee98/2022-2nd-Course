'''
    22.09.23. Seokju Lee
    Modified for python3
    Original code from https://github.com/Leo-LiHao/OpenCV-Python-Tutorials
'''
import cv2 as cv
import time
import numpy as np
from matplotlib import pyplot as plt
import pdb


figNum = 0

if __name__ == '__main__':
    Img = cv.imread('../../../Datas/lena.png')
    AffineMatrix = np.array([[1, 0, 100],
                             [0, 1,  50]], dtype=np.float32)
    DstImg = cv.warpAffine(Img, AffineMatrix, (Img.shape[0]+200, Img.shape[1]+200), borderValue=(155, 155, 155))

    figNum+=1; plt.figure(figNum); plt.imshow(cv.cvtColor(Img, cv.COLOR_BGR2RGB)); plt.ion(); plt.show();
    figNum+=1; plt.figure(figNum); plt.imshow(cv.cvtColor(DstImg, cv.COLOR_BGR2RGB)); plt.ion(); plt.show();
    '''
        Q. Why do we need cv.cvtColor?
    '''

    RotateMatrix = cv.getRotationMatrix2D(center=(Img.shape[1]/2, Img.shape[0]/2),
                                           angle=90,
                                           scale=1)
    print('(Img.shape[1]/2, Img.shape[0]/2):', (Img.shape[1]/2, Img.shape[0]/2))
    print('Rotate Matrix:', RotateMatrix)
    '''
        Q. Please discuss how to generate rotation matrix.
    '''

    RotImg = cv.warpAffine(Img, RotateMatrix, (Img.shape[0], Img.shape[1]))

    CVInv_M = cv.invertAffineTransform(RotateMatrix)
    RotImg2 = cv.warpAffine(Img, CVInv_M, (Img.shape[0], Img.shape[1]))
    '''
        Q. Please discuss the meaning of inverse matrix.

        Q. Please try different rotations, and repeat the process.
    '''

    M = np.vstack((RotateMatrix, np.array([0., 0., 1.])))
    InvM = np.linalg.inv(M)

    figNum+=1; plt.figure(figNum); plt.imshow(cv.cvtColor(RotImg, cv.COLOR_BGR2RGB)); plt.ion(); plt.show();
    figNum+=1; plt.figure(figNum); plt.imshow(cv.cvtColor(RotImg2, cv.COLOR_BGR2RGB)); plt.ion(); plt.show();


    
    pdb.set_trace()

